#Клас DiscountCalculator використовує DSL для обчислення знижки на товар в інтернет-магазині.
class DiscountCalculator
  #Конструктор класу приймає блок коду DSL і виконує його в контексті об'єкта класу.
  def initialize(&block)
    instance_eval(&block) if block_given?
  end

  #Метод DSL для встановлення базової ціни товару без знижки.
  def base_price(price)
    @base_price = price
  end

  #Метод DSL для встановлення величини знижки в процентах.
  def discount(percentage)
    @discount_percentage = percentage
  end

  #Метод, який обчислює та виводить інформацію про ціну без знижки, величину знижки та ціну зі знижкою.
  def apply_discount
    #Обчислення величини знижки та ціни зі знижкою.
    discount_amount = (@base_price * @discount_percentage / 100.0).round(2)
    discounted_price = @base_price - discount_amount

    #Результат.
    puts "Ціна без знижки: #{@base_price}"
    puts "Знижка (#{@discount_percentage}%): #{discount_amount}"
    puts "Ціна зі знижкою: #{discounted_price}"
  end
end


puts "Введіть ціну товару без знижки:"
base_price = gets.chomp.to_f

puts "Введіть величину знижки в процентах:"
discount_percentage = gets.chomp.to_f

#Створення об'єкта DiscountCalculator та використання DSL для налаштування параметрів знижки.
calculator = DiscountCalculator.new do
  base_price base_price
  discount discount_percentage
end

#Застосування знижки та виведення результатів.
calculator.apply_discount
